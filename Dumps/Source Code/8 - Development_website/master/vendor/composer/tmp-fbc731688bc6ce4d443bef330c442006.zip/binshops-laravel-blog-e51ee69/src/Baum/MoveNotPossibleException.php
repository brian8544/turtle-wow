<?php
namespace BinshopsBlog\Baum;

class MoveNotPossibleException extends \RuntimeException {}
