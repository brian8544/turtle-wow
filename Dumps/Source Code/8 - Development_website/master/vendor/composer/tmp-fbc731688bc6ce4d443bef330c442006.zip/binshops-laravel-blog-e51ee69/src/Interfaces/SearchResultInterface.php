<?php namespace BinshopsBlog\Interfaces;

interface SearchResultInterface
{
    public function search_result_page_url();
    public function search_result_page_title();
}