by <strong>{{$post->author->name}}</strong>
