<div class='alert alert-danger'>
    error!
    custom_comments: You must customise this by creating a file in
    /resources/views/vendor/binshopsblog/partials/custom_comments.blade.php
</div>
