<?php

declare(strict_types=1);

namespace BTCPayServer\Result;

class StorePaymentMethodLightningNetwork extends AbstractStorePaymentMethodResult
{
}
