<?php

declare(strict_types=1);

namespace BTCPayServer\Result;

class StorePaymentMethodOnChain extends AbstractStorePaymentMethodResult
{
}
