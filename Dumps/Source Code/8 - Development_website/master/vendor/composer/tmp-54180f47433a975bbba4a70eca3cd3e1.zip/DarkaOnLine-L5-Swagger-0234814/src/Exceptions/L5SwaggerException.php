<?php

namespace L5Swagger\Exceptions;

class L5SwaggerException extends \Exception
{
}
